import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "10mb" }));

// Lazy initialization for Gemini client to prevent crashes if key is missing during boot
let aiClient: GoogleGenAI | null = null;
function getGenAI(): GoogleGenAI | null {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey) {
      aiClient = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });
    }
  }
  return aiClient;
}

// Health API
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", appName: "Clic Graphic Design & Print API" });
});

// Gemini AI Design Assistant API
app.post("/api/ai/assistant", async (req, res) => {
  try {
    const { prompt, mode = "general", contextData } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: "El campo 'prompt' es requerido." });
    }

    const ai = getGenAI();
    if (!ai) {
      return res.status(503).json({
        error: "El servicio de Inteligencia Artificial Clic Assistant se está iniciando. Por favor verifica las credenciales en Secrets.",
        fallbackResponse: getFallbackAIAnswer(prompt, mode),
      });
    }

    let systemInstruction = `Eres "Clic Assistant", el asesor experto en diseño gráfico, identidad visual e imprenta digital/offset de la agencia "Clic".
Tu objetivo es brindar respuestas profesionales, amables, concisas y sumamente útiles en español a clientes y diseñadores.
Responde con tono profesional pero accesible y creativo. Utiliza formato claro con viñetas cuando sea apropiado.
Conoces especificaciones técnicas de imprenta:
- Resolución: 300 DPI para impresión física, 72 DPI para web.
- Modo de color: CMYK para impresión, RGB para pantallas.
- Sangrado/Bleed: 3mm a 5mm perimetrales para corte perfecto.
- Papeles: Couclé 150g/200g para flyers, 350g con Soft Touch y Barniz UVI para tarjetas de presentación impactantes, Kraft para empaques eco.
- Acabados: Stamping oro/plata en caliente, troquelado personalizado, relieve seco, vinilo microperforado y lonas PET anti-curvatura.`;

    if (mode === "slogan") {
      systemInstruction += `\nModo Especializado: Generador de Slogans y Nombres de Marca.
Devuelve entre 3 y 5 opciones creativas, pegajosas y alineadas al concepto del cliente, explicando brevemente el concepto de cada una.`;
    } else if (mode === "print-spec") {
      systemInstruction += `\nModo Especializado: Asesor de Especificaciones Técnicas de Imprenta.
Asegúrate de detallar dimensiones estándar, sangrado, margen de seguridad, tipo de papel recomendado (gramaje), acabados sugeridos y recomendaciones para el archivo final (PDF/X-1a, curvas convertidas, 300 DPI).`;
    } else if (mode === "palette") {
      systemInstruction += `\nModo Especializado: Diseñador de Paletas de Color.
Recomienda una paleta de 4-5 colores con sus códigos HEX y equivalentes CMYK aproximados, explicando la psicología y la aplicación sugerida de cada color.`;
    }

    let userContent = prompt;
    if (contextData) {
      userContent += `\n[Contexto del Proyecto/Producto: ${JSON.stringify(contextData)}]`;
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: userContent,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    const textOutput = response.text || "No se pudo generar una respuesta detallada.";
    return res.json({ text: textOutput, mode });
  } catch (err: any) {
    console.error("Error in /api/ai/assistant:", err);
    return res.status(500).json({
      error: "Ocurrió un inconveniente al conectar con Clic Assistant.",
      fallbackResponse: getFallbackAIAnswer(req.body.prompt || "", req.body.mode || "general"),
    });
  }
});

// Fallback AI responses for smooth UX if API key is unconfigured
function getFallbackAIAnswer(prompt: string, mode: string): string {
  const p = prompt.toLowerCase();
  if (mode === "slogan" || p.includes("slogan") || p.includes("nombre")) {
    return `✨ **Ideas de Slogans por Clic Design Studio:**
1. *"Impacto visual a un Clic de distancia."*
2. *"Imprimimos la personalidad de tu marca."*
3. *"Diseño inteligente, resultados extraordinarios."*
4. *"Donde las grandes ideas cobran forma física y digital."*`;
  }
  if (mode === "print-spec" || p.includes("tarjeta") || p.includes("impresion") || p.includes("papel")) {
    return `📐 **Especificaciones Recomendadas de Imprenta Clic:**
- **Resolución:** 300 DPI en tamaño real.
- **Modo de Color:** CMYK (Coated FOGRA39).
- **Sangrado (Bleed):** 3 mm por cada lado.
- **Margen Interno de Seguridad:** 4 mm desde el borde del corte.
- **Papel Recomendado:** Couclé de 350g con laminado mate Soft Touch y Barniz UVI sectorizado en tu logo.
- **Formato de Archivo:** PDF/X-1a con fuentes convertidas a curvas o trazados.`;
  }
  return `👋 **Asistente Clic:** ¡Hola! En Clic combinamos el mejor diseño gráfico con tecnología de impresión offset y digital de máxima resolución.
Podemos ayudarte con:
- Creación de identidad de marca, logotipos y manual de estilo.
- Preparación de archivos para imprenta (sangrado, CMYK, 300 DPI).
- Selección de papelería, empaques y acabados premium (Soft Touch, Stamping, UVI).
- Cotizaciones personalizadas para grandes volúmenes o eventos.`;
}

// Quote Calculation & Submission API
app.post("/api/quotes/calculate", (req, res) => {
  const { quantity = 100, serviceType = "tarjetas", paperType = "standard", finishType = "none", urgency = "normal" } = req.body;
  
  let baseUnit = 5.00;
  if (serviceType === "tarjetas") baseUnit = 6.80;
  if (serviceType === "flyers") baseUnit = 3.96;
  if (serviceType === "roll-up") baseUnit = 1600.00;
  if (serviceType === "stickers") baseUnit = 8.50;
  if (serviceType === "bolsas") baseUnit = 23.50;
  if (serviceType === "branding") baseUnit = 2500.00;

  if (paperType.includes("350g") || paperType.includes("soft-touch")) baseUnit *= 1.25;
  if (finishType.includes("uvi") || finishType.includes("stamping")) baseUnit += 2.50;

  let total = baseUnit * quantity;
  if (quantity >= 500) total *= 0.80; // 20% discount
  else if (quantity >= 250) total *= 0.88; // 12% discount

  if (urgency === "express") total *= 1.20;
  if (urgency === "super-express") total *= 1.45;

  res.json({
    unitPrice: parseFloat((total / quantity).toFixed(2)),
    totalEstimated: parseFloat(total.toFixed(2)),
    discountPercent: quantity >= 500 ? 20 : quantity >= 250 ? 12 : 0,
    estimatedDays: urgency === "super-express" ? 1 : urgency === "express" ? 2 : 4,
  });
});

// Mock Orders Database in memory for demo session
const MOCK_ORDERS: Record<string, any> = {
  "CLIC-9821": {
    id: "CLIC-9821",
    customerName: "Camila Torres",
    email: "camila@novatech.com",
    date: "2026-08-05",
    status: "printing",
    items: [
      { name: "Tarjetas de Presentación Premium Soft Touch", quantity: 500, details: "Papel Couclé 350g + Barniz UVI" }
    ],
    totalAmount: 2600.00,
    estimatedDelivery: "2026-08-08",
    trackingNumber: "EXP-8890122",
    history: [
      { stage: "Pedido Recibido", date: "05/08 09:30", completed: true, description: "Orden registrada y pago confirmado." },
      { stage: "Preprensa & Control de Archivos", date: "05/08 11:15", completed: true, description: "Verificación de sangrado, DPIs y CMYK aprobada." },
      { stage: "En Imprenta Offset", date: "06/08 08:00", completed: true, description: "Impresión de pliegos a 4 tintas en proceso." },
      { stage: "Acabados & Troquelado", date: "06/08 15:30", completed: false, description: "Aplicación de Soft Touch y Barniz UVI." },
      { stage: "En Clic Despacho", date: "Pendiente", completed: false, description: "Empaquetado protector y envío con mensajería." }
    ]
  }
};

app.post("/api/orders/create", (req, res) => {
  const { customerName, email, items, totalAmount } = req.body;
  const newId = `CLIC-${Math.floor(1000 + Math.random() * 9000)}`;
  
  const newOrder = {
    id: newId,
    customerName: customerName || "Cliente Clic",
    email: email || "cliente@ejemplo.com",
    date: new Date().toISOString().split("T")[0],
    status: "received",
    items: items || [],
    totalAmount: totalAmount || 0,
    estimatedDelivery: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
    trackingNumber: `EXP-${Math.floor(100000 + Math.random() * 900000)}`,
    history: [
      { stage: "Pedido Recibido", date: "Hoy", completed: true, description: "Orden registrada en la plataforma Clic." },
      { stage: "Preprensa & Control de Archivos", date: "Próximo", completed: false, description: "Validación de color y resolución de diseño." },
      { stage: "En Imprenta", date: "Pendiente", completed: false, description: "Producción física." },
      { stage: "Envío & Entrega", date: "Pendiente", completed: false, description: "Rumbo a la dirección del cliente." }
    ]
  };

  MOCK_ORDERS[newId] = newOrder;
  res.json({ success: true, order: newOrder });
});

app.get("/api/orders/track/:orderId", (req, res) => {
  const orderId = req.params.orderId.toUpperCase().trim();
  const found = MOCK_ORDERS[orderId];
  if (!found) {
    return res.status(404).json({ error: `No se encontró ningún pedido con el código '${orderId}'. Prueba con 'CLIC-9821'.` });
  }
  return res.json(found);
});

// Vite & Static file serving setup
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Clic Studio] Servidor iniciado en http://localhost:${PORT}`);
  });
}

startServer();
