import React from 'react';
import { ArrowRight, Sparkles, Printer, Layers, ShieldCheck, CheckCircle2, FileUp, Cpu } from 'lucide-react';

interface HeroSectionProps {
  onExplorePortfolio: () => void;
  onExploreCatalog: () => void;
  onOpenQuote: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onExplorePortfolio,
  onExploreCatalog,
  onOpenQuote,
}) => {
  return (
    <section id="hero" className="relative overflow-hidden bg-slate-950 text-white pt-12 pb-20 border-b border-slate-800">
      {/* Background Ambient Glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 bg-gradient-to-tr from-blue-600/20 via-cyan-500/10 to-indigo-600/20 blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column Text & CTAs */}
          <div className="lg:col-span-7 space-y-8 text-center lg:text-left">
            
            {/* Top Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-900 border border-slate-800 text-slate-300 text-xs font-semibold">
              <span className="flex h-2 w-2 rounded-full bg-cyan-400 animate-ping" />
              <span className="text-cyan-400 font-bold">Clic Graphic Studio & Imprenta</span>
              <span className="text-slate-500">•</span>
              <span>Soluciones 360° en Diseño e Impresión</span>
            </div>

            {/* Main Title */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight leading-tight">
              A tan solo un{' '}
              <span className="bg-gradient-to-r from-cyan-400 via-blue-500 to-indigo-400 bg-clip-text text-transparent">
                Clic
              </span>{' '}
              de potenciar la imagen de tu marca.
            </h1>

            {/* Subtitle */}
            <p className="text-lg text-slate-300 max-w-2xl font-normal leading-relaxed mx-auto lg:mx-0">
              Transformamos conceptos en experiencias memorables. Desde el diseño de tu identidad corporativa, logotipos y empaques hasta la producción en imprenta offset, gran formato y artículos personalizados.
            </p>

            {/* Feature Bullets */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-sm text-slate-300 pt-2">
              <div className="flex items-center justify-center lg:justify-start gap-2 bg-slate-900/60 p-2.5 rounded-xl border border-slate-800">
                <CheckCircle2 className="w-4 h-4 text-cyan-400 flex-shrink-0" />
                <span className="font-medium text-xs">Portafolio Profesional</span>
              </div>
              <div className="flex items-center justify-center lg:justify-start gap-2 bg-slate-900/60 p-2.5 rounded-xl border border-slate-800">
                <Printer className="w-4 h-4 text-cyan-400 flex-shrink-0" />
                <span className="font-medium text-xs">Imprenta Digital & Offset</span>
              </div>
              <div className="flex items-center justify-center lg:justify-start gap-2 bg-slate-900/60 p-2.5 rounded-xl border border-slate-800">
                <Cpu className="w-4 h-4 text-cyan-400 flex-shrink-0" />
                <span className="font-medium text-xs">Asistente Clic IA</span>
              </div>
            </div>

            {/* Primary Action Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-4">
              <button
                onClick={onExplorePortfolio}
                className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-gradient-to-r from-blue-600 via-blue-500 to-cyan-500 text-white font-bold text-sm hover:opacity-95 transition shadow-lg shadow-blue-600/25 flex items-center justify-center gap-2 cursor-pointer group"
              >
                <span>Ver Portafolio de Diseño</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={onExploreCatalog}
                className="w-full sm:w-auto px-7 py-3.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-100 font-bold text-sm hover:bg-slate-800 hover:border-cyan-500/50 transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <Printer className="w-4 h-4 text-cyan-400" />
                <span>Tienda de Imprenta</span>
              </button>

              <button
                onClick={onOpenQuote}
                className="w-full sm:w-auto px-5 py-3.5 rounded-xl text-cyan-400 hover:bg-cyan-950/40 font-semibold text-sm transition border border-cyan-500/30 flex items-center justify-center gap-2 cursor-pointer"
              >
                <Sparkles className="w-4 h-4" />
                <span>Cotizador Rápido</span>
              </button>
            </div>

          </div>

          {/* Right Column Showcase Cards */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl bg-gradient-to-b from-slate-900 to-slate-950 p-6 border border-slate-800 shadow-2xl space-y-6">
              
              {/* Card Header */}
              <div className="flex items-center justify-between pb-4 border-b border-slate-800">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400 font-bold">
                    <Layers className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white">Servicios de Estudio & Imprenta</h3>
                    <p className="text-xs text-slate-400">Calidad garantizada 300 DPI</p>
                  </div>
                </div>
                <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
                  En línea
                </span>
              </div>

              {/* Showcase Grid */}
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-1.5 hover:border-cyan-500/40 transition">
                  <div className="w-8 h-8 rounded-lg bg-cyan-500/10 flex items-center justify-center text-cyan-400">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <h4 className="text-xs font-bold text-slate-200">Branding e Identidad</h4>
                  <p className="text-[11px] text-slate-400">Logotipos, manuales de marca y papelería corporativa.</p>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-1.5 hover:border-cyan-500/40 transition">
                  <div className="w-8 h-8 rounded-lg bg-blue-500/10 flex items-center justify-center text-blue-400">
                    <Printer className="w-4 h-4" />
                  </div>
                  <h4 className="text-xs font-bold text-slate-200">Tarjetas Soft Touch</h4>
                  <p className="text-[11px] text-slate-400">Barniz UVI sectorizado y stamping metálico.</p>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-1.5 hover:border-cyan-500/40 transition">
                  <div className="w-8 h-8 rounded-lg bg-indigo-500/10 flex items-center justify-center text-indigo-400">
                    <Layers className="w-4 h-4" />
                  </div>
                  <h4 className="text-xs font-bold text-slate-200">Gran Formato</h4>
                  <p className="text-[11px] text-slate-400">Banners roll-up, lonas publicitarias y vinilos.</p>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-1.5 hover:border-cyan-500/40 transition">
                  <div className="w-8 h-8 rounded-lg bg-cyan-500/10 flex items-center justify-center text-cyan-400">
                    <FileUp className="w-4 h-4" />
                  </div>
                  <h4 className="text-xs font-bold text-slate-200">Subida de Archivos</h4>
                  <p className="text-[11px] text-slate-400">Verificación de preprensa antes de imprimir.</p>
                </div>
              </div>

              {/* Quality Guarantee Ribbon */}
              <div className="p-3 bg-gradient-to-r from-blue-950/60 to-slate-900 rounded-xl border border-blue-800/40 flex items-center justify-between text-xs text-slate-300">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-cyan-400" />
                  <span>Control de calidad en preprensa e impresión</span>
                </div>
                <span className="font-bold text-white">100% Clic</span>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
