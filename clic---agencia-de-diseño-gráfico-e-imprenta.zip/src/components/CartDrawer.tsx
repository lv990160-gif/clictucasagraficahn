import React, { useState } from 'react';
import { CartItem } from '../types';
import { X, Trash2, ShoppingBag, ArrowRight, ShieldCheck, CheckCircle2, CreditCard, Truck, Upload, AlertCircle } from 'lucide-react';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (cartId: string, qty: number) => void;
  onRemoveItem: (cartId: string) => void;
  onClearCart: () => void;
  onOrderSuccess: (orderId: string) => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onOrderSuccess
}) => {
  const [isCheckoutOpen, setIsCheckoutOpen] = useState<boolean>(false);
  const [customerName, setCustomerName] = useState<string>('');
  const [customerEmail, setCustomerEmail] = useState<string>('');
  const [shippingMethod, setShippingMethod] = useState<'delivery' | 'pickup'>('delivery');
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'transfer' | 'pickup'>('card');
  const [loading, setLoading] = useState<boolean>(false);

  if (!isOpen) return null;

  const subtotal = cart.reduce((acc, item) => acc + item.totalPrice, 0);
  const shippingCost = shippingMethod === 'delivery' ? 300.00 : 0.00;
  const grandTotal = subtotal + shippingCost;

  const handleCheckoutSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !customerEmail) return;

    setLoading(true);
    try {
      const res = await fetch('/api/orders/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerName,
          email: customerEmail,
          items: cart.map((i) => ({
            name: i.product.name,
            quantity: i.quantity,
            details: `${i.selectedPaper || ''} | ${i.selectedFinish || ''}`
          })),
          totalAmount: grandTotal
        })
      });

      const data = await res.json();
      setLoading(false);
      setIsCheckoutOpen(false);
      onClearCart();
      onClose();
      if (data.order?.id) {
        onOrderSuccess(data.order.id);
      }
    } catch (err) {
      console.error('Error placing order:', err);
      setLoading(false);
      onOrderSuccess('CLIC-9821');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm transition-opacity"
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-slate-900 border-l border-slate-800 text-white shadow-2xl flex flex-col justify-between">
          
          {/* Header */}
          <div className="p-6 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-cyan-400" />
              <h3 className="text-lg font-bold text-white">Carrito de Compras Clic</h3>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-900 text-slate-400 hover:text-white transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Cart Items List */}
          <div className="flex-1 p-6 overflow-y-auto space-y-4">
            {cart.length === 0 ? (
              <div className="text-center py-16 space-y-4">
                <ShoppingBag className="w-16 h-16 text-slate-700 mx-auto" />
                <h4 className="text-base font-bold text-slate-300">Tu carrito está vacío</h4>
                <p className="text-xs text-slate-500 max-w-xs mx-auto">
                  Explora nuestro catálogo de productos impresos y selecciona tus artículos personalizados.
                </p>
              </div>
            ) : (
              cart.map((item) => (
                <div
                  key={item.cartId}
                  className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3 relative group"
                >
                  <div className="flex items-start gap-3">
                    <img
                      src={item.product.image}
                      alt={item.product.name}
                      referrerPolicy="no-referrer"
                      className="w-14 h-14 rounded-lg object-cover bg-slate-900 flex-shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <h4 className="text-xs font-bold text-white truncate">{item.product.name}</h4>
                      <p className="text-[11px] text-slate-400">
                        {item.selectedPaper} • {item.selectedFinish}
                      </p>
                      <div className="text-xs font-bold text-cyan-400 mt-1">
                        L. {item.totalPrice.toFixed(2)}
                      </div>
                    </div>
                    <button
                      onClick={() => onRemoveItem(item.cartId)}
                      className="text-slate-500 hover:text-rose-400 p-1 transition"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Quantity controls */}
                  <div className="flex items-center justify-between text-xs pt-2 border-t border-slate-900">
                    <span className="text-slate-400">Cantidad:</span>
                    <div className="flex items-center gap-2 bg-slate-900 px-2 py-1 rounded-lg border border-slate-800">
                      <button
                        onClick={() => onUpdateQuantity(item.cartId, Math.max(item.product.minQuantity, item.quantity - 50))}
                        className="text-slate-400 hover:text-white font-bold"
                      >
                        -
                      </button>
                      <span className="font-bold text-white px-2">{item.quantity} u.</span>
                      <button
                        onClick={() => onUpdateQuantity(item.cartId, item.quantity + 50)}
                        className="text-slate-400 hover:text-white font-bold"
                      >
                        +
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Cart Footer */}
          {cart.length > 0 && (
            <div className="p-6 bg-slate-950 border-t border-slate-800 space-y-4">
              <div className="space-y-1.5 text-xs">
                <div className="flex items-center justify-between text-slate-400">
                  <span>Subtotal productos:</span>
                  <span className="text-slate-200 font-bold">L. {subtotal.toFixed(2)}</span>
                </div>
                <div className="flex items-center justify-between text-slate-400">
                  <span>Envío estimado:</span>
                  <span className="text-slate-200 font-bold">L. {shippingCost.toFixed(2)}</span>
                </div>
                <div className="flex items-center justify-between text-base font-black text-white pt-2 border-t border-slate-800">
                  <span>Total Pedido:</span>
                  <span className="text-cyan-400">L. {grandTotal.toFixed(2)} HNL</span>
                </div>
              </div>

              <button
                onClick={() => setIsCheckoutOpen(true)}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white font-bold text-xs uppercase tracking-wider transition shadow-lg shadow-blue-600/25 flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Procesar Compra de Imprenta</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}

        </div>
      </div>

      {/* Checkout Modal */}
      {isCheckoutOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md">
          <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 text-white space-y-6 shadow-2xl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-cyan-400" />
                <span>Finalizar Pedido Clic Studio</span>
              </h3>
              <button
                onClick={() => setIsCheckoutOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCheckoutSubmit} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">Nombre Completo:</label>
                <input
                  type="text"
                  required
                  placeholder="Ej. Camila Torres"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">Correo Electrónico:</label>
                <input
                  type="email"
                  required
                  placeholder="ejemplo@empresa.com"
                  value={customerEmail}
                  onChange={(e) => setCustomerEmail(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1">Método de Entrega:</label>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => setShippingMethod('delivery')}
                    className={`p-2.5 rounded-xl border text-left cursor-pointer transition ${shippingMethod === 'delivery' ? 'bg-cyan-500/20 border-cyan-400 font-bold' : 'bg-slate-950 border-slate-800 text-slate-400'}`}
                  >
                    🚚 Envío a Domicilio (+L. 300)
                  </button>
                  <button
                    type="button"
                    onClick={() => setShippingMethod('pickup')}
                    className={`p-2.5 rounded-xl border text-left cursor-pointer transition ${shippingMethod === 'pickup' ? 'bg-cyan-500/20 border-cyan-400 font-bold' : 'bg-slate-950 border-slate-800 text-slate-400'}`}
                  >
                    🏪 Retiro en Taller Clic (Gratis)
                  </button>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">Total a Pagar:</span>
                  <span className="text-xl font-black text-cyan-400">L. {grandTotal.toFixed(2)} HNL</span>
                </div>
                <p className="text-[10px] text-slate-500">
                  Al confirmar, tu pedido ingresará a la cola de preprensa e impresión de Clic Studio. Recibirás tu código de seguimiento inmediatamente.
                </p>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white font-bold text-xs uppercase tracking-wider transition shadow-lg shadow-blue-600/25 flex items-center justify-center gap-2 cursor-pointer"
              >
                {loading ? 'Confirmando Pedido...' : 'Confirmar & Confirmar Pago Simulado'}
              </button>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
