import React, { useState } from 'react';
import { Sparkles, Send, Bot, User, RefreshCw, Palette, Lightbulb, FileCheck2, Zap } from 'lucide-react';
import { AiChatMessage } from '../types';

export const AiDesignAssistant: React.FC = () => {
  const [messages, setMessages] = useState<AiChatMessage[]>([
    {
      id: 'welcome',
      sender: 'assistant',
      text: '¡Hola! Soy Clic Assistant, tu asesor de diseño e imprenta impulsado por IA. ¿En qué puedo orientarte hoy? Puedo ayudarte a redactar slogans, verificar especificaciones para imprenta (DPI, CMYK, sangrado) o recomendar paletas de color para tu marca.',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);

  const [inputPrompt, setInputPrompt] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [activeMode, setActiveMode] = useState<'general' | 'slogan' | 'print-spec' | 'palette'>('general');

  const quickPrompts = [
    { label: '💡 Generar 4 slogans creativos para mi marca', prompt: 'Genera 4 slogans atractivos y profesionales para mi negocio de alimentos orgánicos.', mode: 'slogan' as const },
    { label: '📐 Especificaciones para imprimir tarjetas 300 DPI', prompt: '¿Cuáles son las medidas, sangrado y resolución recomendados para imprimir tarjetas de presentación con acabado Soft Touch?', mode: 'print-spec' as const },
    { label: '🎨 Paleta de colores para identidad corporativa', prompt: 'Sugiere una paleta de 4 colores moderna y elegante para un estudio de arquitectura con sus códigos HEX y psicología.', mode: 'palette' as const },
    { label: '🖨️ ¿Cuál es la diferencia entre CMYK y RGB?', prompt: 'Explícame de forma breve por qué debo convertir mi diseño a CMYK antes de mandarlo a imprenta offset.', mode: 'general' as const }
  ];

  const handleSendMessage = async (promptToSend?: string, modeToSend?: string) => {
    const text = promptToSend || inputPrompt;
    if (!text.trim() || loading) return;

    const userMsg: AiChatMessage = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!promptToSend) setInputPrompt('');
    setLoading(true);

    try {
      const mode = modeToSend || activeMode;
      const res = await fetch('/api/ai/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: text,
          mode
        })
      });

      const data = await res.json();
      const aiResponseText = data.text || data.fallbackResponse || 'No pude procesar la solicitud en este momento.';

      const botMsg: AiChatMessage = {
        id: `bot-${Date.now()}`,
        sender: 'assistant',
        text: aiResponseText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages((prev) => [...prev, botMsg]);
    } catch (err) {
      console.error('Error contacting Clic Assistant API:', err);
      const errorMsg: AiChatMessage = {
        id: `err-${Date.now()}`,
        sender: 'assistant',
        text: 'Ocurrió una pausa temporal con la conexión. Sin embargo, en Clic recomendamos utilizar 300 DPI, modo CMYK con 3mm de sangrado perimetral para cualquier trabajo impreso.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <section id="ai-assistant" className="py-20 bg-slate-950 text-white border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-gradient-to-r from-blue-600/20 to-cyan-500/20 border border-cyan-500/30 text-cyan-400 text-xs font-bold uppercase tracking-wider">
            <Bot className="w-4 h-4" />
            <span>Inteligencia Artificial Clic Studio</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
            Asistente Creativo & Asesor Técnico
          </h2>
          <p className="text-slate-400 text-sm sm:text-base">
            Obtén respuestas instantáneas respaldadas por la API de Gemini para la preparación de tus archivos de diseño, redacción de copys comerciales y especificaciones de imprenta.
          </p>
        </div>

        {/* Chat Window Container */}
        <div className="max-w-4xl mx-auto bg-slate-900 rounded-2xl border border-slate-800 shadow-2xl overflow-hidden flex flex-col h-[600px]">
          
          {/* Chat Window Header */}
          <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white font-black shadow-md shadow-cyan-500/20">
                <Sparkles className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <span>Clic Assistant IA</span>
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                </h3>
                <p className="text-[11px] text-slate-400">Gemini 3.6 Flash Server Engine</p>
              </div>
            </div>

            {/* Mode Selectors */}
            <div className="hidden sm:flex items-center gap-1 bg-slate-900 p-1 rounded-lg border border-slate-800">
              <button
                onClick={() => setActiveMode('general')}
                className={`px-2.5 py-1 text-xs font-bold rounded cursor-pointer transition ${activeMode === 'general' ? 'bg-cyan-500 text-slate-950' : 'text-slate-400 hover:text-white'}`}
              >
                General
              </button>
              <button
                onClick={() => setActiveMode('slogan')}
                className={`px-2.5 py-1 text-xs font-bold rounded cursor-pointer transition ${activeMode === 'slogan' ? 'bg-cyan-500 text-slate-950' : 'text-slate-400 hover:text-white'}`}
              >
                Slogans
              </button>
              <button
                onClick={() => setActiveMode('print-spec')}
                className={`px-2.5 py-1 text-xs font-bold rounded cursor-pointer transition ${activeMode === 'print-spec' ? 'bg-cyan-500 text-slate-950' : 'text-slate-400 hover:text-white'}`}
              >
                Imprenta
              </button>
            </div>
          </div>

          {/* Quick Action Chips */}
          <div className="p-3 bg-slate-950/60 border-b border-slate-800 overflow-x-auto flex gap-2 no-scrollbar">
            {quickPrompts.map((qp, idx) => (
              <button
                key={idx}
                onClick={() => handleSendMessage(qp.prompt, qp.mode)}
                className="whitespace-nowrap px-3 py-1.5 rounded-full bg-slate-900 border border-slate-800 hover:border-cyan-500/50 text-slate-300 hover:text-white text-xs font-medium transition cursor-pointer flex-shrink-0"
              >
                {qp.label}
              </button>
            ))}
          </div>

          {/* Messages Stream Area */}
          <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4 bg-slate-900/90">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-3 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {msg.sender === 'assistant' && (
                  <div className="w-8 h-8 rounded-lg bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-cyan-400 flex-shrink-0 mt-1">
                    <Bot className="w-4 h-4" />
                  </div>
                )}

                <div className={`max-w-[80%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed space-y-2 ${
                  msg.sender === 'user'
                    ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-tr-none shadow-md'
                    : 'bg-slate-950 border border-slate-800 text-slate-200 rounded-tl-none'
                }`}>
                  <div className="whitespace-pre-wrap font-sans">
                    {msg.text}
                  </div>
                  <span className="text-[10px] text-slate-400 block text-right">
                    {msg.timestamp}
                  </span>
                </div>

                {msg.sender === 'user' && (
                  <div className="w-8 h-8 rounded-lg bg-cyan-500/20 border border-cyan-500/30 flex items-center justify-center text-cyan-400 flex-shrink-0 mt-1">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            ))}

            {loading && (
              <div className="flex gap-3 items-center text-slate-400 text-xs italic">
                <div className="w-8 h-8 rounded-lg bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-cyan-400 animate-spin">
                  <RefreshCw className="w-4 h-4" />
                </div>
                <span>Clic Assistant está analizando y redactando la respuesta...</span>
              </div>
            )}
          </div>

          {/* Input Footer */}
          <div className="p-4 bg-slate-950 border-t border-slate-800">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="flex items-center gap-2"
            >
              <input
                type="text"
                placeholder="Escribe tu consulta sobre diseño, slogans o impresión..."
                value={inputPrompt}
                onChange={(e) => setInputPrompt(e.target.value)}
                className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 text-xs sm:text-sm text-white focus:outline-none focus:border-cyan-400"
              />
              <button
                type="submit"
                disabled={loading || !inputPrompt.trim()}
                className="px-5 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white font-bold text-xs uppercase transition shadow-md flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              >
                <Send className="w-4 h-4" />
                <span className="hidden sm:inline">Consultar</span>
              </button>
            </form>
          </div>

        </div>

      </div>
    </section>
  );
};
