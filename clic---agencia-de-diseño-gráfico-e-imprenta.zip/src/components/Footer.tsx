import React from 'react';
import { Layers, Heart, ShieldCheck } from 'lucide-react';
import { Logo } from './Logo';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-950 text-slate-400 text-xs border-t border-slate-900 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          
          {/* Brand Info */}
          <div className="space-y-3">
            <Logo size="sm" />
            <p className="text-slate-500 leading-relaxed text-[11px]">
              Agencia de Diseño Gráfico, Identidad Visual e Imprenta Digital/Offset de Alta Definición.
            </p>
          </div>

          {/* Quick Links */}
          <div className="space-y-2">
            <h4 className="font-bold text-white text-xs uppercase tracking-wider">Especialidades</h4>
            <ul className="space-y-1.5 text-[11px] text-slate-400">
              <li>• Branding & Logotipos</li>
              <li>• Tarjetas Soft Touch + UVI</li>
              <li>• Gran Formato & Roll-Ups</li>
              <li>• Empaques & Bolsas Kraft</li>
            </ul>
          </div>

          {/* Print Standards */}
          <div className="space-y-2">
            <h4 className="font-bold text-white text-xs uppercase tracking-wider">Estándares de Imprenta</h4>
            <ul className="space-y-1.5 text-[11px] text-slate-400">
              <li>• Impresión 300 DPI Ultra HD</li>
              <li>• Calibración de Color CMYK</li>
              <li>• Control de Sangrado 3mm</li>
              <li>• Troquelado Personalizado</li>
            </ul>
          </div>

          {/* Payment & Security */}
          <div className="space-y-2">
            <h4 className="font-bold text-white text-xs uppercase tracking-wider">Calidad Garantizada</h4>
            <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-1">
              <div className="flex items-center gap-1.5 text-cyan-400 font-bold text-xs">
                <ShieldCheck className="w-4 h-4" />
                <span>Garantía de Impresión Clic</span>
              </div>
              <p className="text-[10px] text-slate-500">
                Verificación humana de archivos antes de producción.
              </p>
            </div>
          </div>

        </div>

        <div className="pt-8 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
          <div>
            © {new Date().getFullYear()} Clic - Agencia de Diseño Gráfico e Imprenta. Todos los derechos reservados.
          </div>
          <div className="flex items-center gap-1">
            <span>Diseñado con pasión por Clic Graphic Studio</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
