import React, { useState } from 'react';
import { PRINT_PRODUCTS } from '../data/productsData';
import { PrintProduct, CartItem, ProductCategory } from '../types';
import { ShoppingBag, Check, Upload, Sparkles, Sliders, ShieldAlert, ArrowRight, Info, Printer } from 'lucide-react';

interface CatalogSectionProps {
  onAddToCart: (item: CartItem) => void;
}

export const CatalogSection: React.FC<CatalogSectionProps> = ({ onAddToCart }) => {
  const [selectedCategory, setSelectedCategory] = useState<ProductCategory>('all');
  const [activeProduct, setActiveProduct] = useState<PrintProduct | null>(PRINT_PRODUCTS[0]);

  // Product customization state
  const [quantity, setQuantity] = useState<number>(PRINT_PRODUCTS[0].minQuantity);
  const [selectedSize, setSelectedSize] = useState<string>(PRINT_PRODUCTS[0].sizeOptions?.[0] || '');
  const [selectedPaper, setSelectedPaper] = useState<string>(PRINT_PRODUCTS[0].paperOptions?.[0] || '');
  const [selectedFinish, setSelectedFinish] = useState<string>(PRINT_PRODUCTS[0].finishOptions?.[0] || '');
  const [needDesignService, setNeedDesignService] = useState<boolean>(false);
  const [uploadedFileName, setUploadedFileName] = useState<string>('');
  const [addedToast, setAddedToast] = useState<boolean>(false);

  const categories: { id: ProductCategory; label: string }[] = [
    { id: 'all', label: 'Todos los Artículos' },
    { id: 'tarjetas', label: 'Tarjetas Corporativas' },
    { id: 'folletos', label: 'Folletos & Flyers' },
    { id: 'gran-formato', label: 'Gran Formato' },
    { id: 'merchandising', label: 'Merchandising & Regalos' },
    { id: 'packaging', label: 'Packaging & Empaques' },
  ];

  const handleSelectProduct = (product: PrintProduct) => {
    setActiveProduct(product);
    setQuantity(product.minQuantity);
    setSelectedSize(product.sizeOptions?.[0] || '');
    setSelectedPaper(product.paperOptions?.[0] || '');
    setSelectedFinish(product.finishOptions?.[0] || '');
    setNeedDesignService(false);
    setUploadedFileName('');
  };

  const filteredProducts = selectedCategory === 'all'
    ? PRINT_PRODUCTS
    : PRINT_PRODUCTS.filter((p) => p.category === selectedCategory);

  // Calculate tier discount
  const getDiscountRate = (prod: PrintProduct, qty: number): number => {
    let disc = 0;
    const sortedTiers = [...prod.quantityTier].sort((a, b) => b.qty - a.qty);
    for (const tier of sortedTiers) {
      if (qty >= tier.qty) {
        disc = tier.discount;
        break;
      }
    }
    return disc;
  };

  const currentDiscount = activeProduct ? getDiscountRate(activeProduct, quantity) : 0;
  
  // Calculate unit and total prices
  const calculateTotal = (): { unitPrice: number; total: number } => {
    if (!activeProduct) return { unitPrice: 0, total: 0 };
    let unit = activeProduct.basePrice / activeProduct.minQuantity;

    if (selectedPaper.includes('Soft Touch') || selectedPaper.includes('Reciclado')) unit *= 1.15;
    if (selectedFinish.includes('UVI') || selectedFinish.includes('Stamping')) unit *= 1.25;

    let subtotal = unit * quantity;
    subtotal = subtotal * (1 - currentDiscount);

    if (needDesignService) {
      subtotal += 600.00; // Flat fee in Lempiras for Clic Graphic Design Service
    }

    return {
      unitPrice: parseFloat((subtotal / quantity).toFixed(2)),
      total: parseFloat(subtotal.toFixed(2))
    };
  };

  const { unitPrice, total } = calculateTotal();

  const handleAddToCart = () => {
    if (!activeProduct) return;

    const cartItem: CartItem = {
      cartId: `cart-${Date.now()}`,
      product: activeProduct,
      quantity,
      selectedSize,
      selectedPaper,
      selectedFinish,
      needDesignService,
      uploadedFileName: uploadedFileName || (needDesignService ? 'Diseño Asignado a Equipo Clic' : 'Archivo pendiente'),
      unitPrice,
      totalPrice: total
    };

    onAddToCart(cartItem);
    setAddedToast(true);
    setTimeout(() => setAddedToast(false), 3000);
  };

  return (
    <section id="catalog" className="py-20 bg-slate-950 text-white border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs font-bold uppercase tracking-wider">
            <Printer className="w-3.5 h-3.5" />
            <span>Catálogo Imprenta Digital & Offset</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
            Tienda Online de Productos Físicos
          </h2>
          <p className="text-slate-400 text-sm sm:text-base">
            Selecciona tu producto impreso, personaliza el gramaje del papel, acabado y cantidad con descuento por volumen. Sube tu diseño listo para imprenta o solicita apoyo de nuestros diseñadores.
          </p>
        </div>

        {/* Category Tabs */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-10">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer ${
                selectedCategory === cat.id
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/25'
                  : 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Catalog Main Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Product Selector Cards */}
          <div className="lg:col-span-5 space-y-3 max-h-[750px] overflow-y-auto pr-2">
            <h3 className="text-xs font-bold uppercase text-slate-400 tracking-wider mb-2">
              Selecciona un Artículo ({filteredProducts.length})
            </h3>

            {filteredProducts.map((prod) => {
              const isSelected = activeProduct?.id === prod.id;
              return (
                <div
                  key={prod.id}
                  onClick={() => handleSelectProduct(prod)}
                  className={`p-4 rounded-xl border transition cursor-pointer flex items-center gap-4 ${
                    isSelected
                      ? 'bg-slate-900 border-cyan-500 shadow-md shadow-cyan-500/10'
                      : 'bg-slate-900/50 border-slate-800 hover:border-slate-700 hover:bg-slate-900/80'
                  }`}
                >
                  <img
                    src={prod.image}
                    alt={prod.name}
                    referrerPolicy="no-referrer"
                    className="w-16 h-16 rounded-lg object-cover flex-shrink-0 bg-slate-950"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1">
                      <h4 className="text-sm font-bold text-white truncate">{prod.name}</h4>
                      {prod.popular && (
                        <span className="text-[9px] font-bold uppercase bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 px-1.5 py-0.5 rounded">
                          Top
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-400 truncate mt-0.5">{prod.shortDesc}</p>
                    <div className="text-xs font-bold text-cyan-400 mt-1">
                      Desde L. {prod.basePrice.toFixed(2)}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Right Column: Interactive Product Configurator */}
          {activeProduct && (
            <div className="lg:col-span-7 bg-slate-900 rounded-2xl p-6 sm:p-8 border border-slate-800 space-y-6 shadow-2xl">
              
              {/* Product Title & Badge */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
                <div>
                  <span className="text-xs font-bold uppercase text-cyan-400">{activeProduct.categoryLabel}</span>
                  <h3 className="text-xl sm:text-2xl font-black text-white">{activeProduct.name}</h3>
                </div>
                <div className="text-left sm:text-right">
                  <span className="text-xs text-slate-400 block">Tiempo estimado:</span>
                  <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2.5 py-1 rounded-full inline-block">
                    ⏱️ {activeProduct.productionDays} días hábiles
                  </span>
                </div>
              </div>

              {/* Product Image & Full Description */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-center">
                <img
                  src={activeProduct.image}
                  alt={activeProduct.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-32 rounded-xl object-cover border border-slate-800 bg-slate-950"
                />
                <p className="sm:col-span-2 text-xs text-slate-300 leading-relaxed bg-slate-950/60 p-3.5 rounded-xl border border-slate-800/80">
                  {activeProduct.description}
                </p>
              </div>

              {/* Options Form */}
              <div className="space-y-4">
                
                {/* Size Selection */}
                {activeProduct.sizeOptions && activeProduct.sizeOptions.length > 0 && (
                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1.5">Tamaño / Formato:</label>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      {activeProduct.sizeOptions.map((size) => (
                        <button
                          key={size}
                          onClick={() => setSelectedSize(size)}
                          className={`p-2.5 text-xs font-medium rounded-xl border transition text-left cursor-pointer ${
                            selectedSize === size
                              ? 'bg-blue-600/20 border-cyan-400 text-white font-bold'
                              : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700'
                          }`}
                        >
                          {size}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Paper Options */}
                {activeProduct.paperOptions && activeProduct.paperOptions.length > 0 && (
                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1.5">Tipo y Gramaje de Papel:</label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {activeProduct.paperOptions.map((paper) => (
                        <button
                          key={paper}
                          onClick={() => setSelectedPaper(paper)}
                          className={`p-2.5 text-xs font-medium rounded-xl border transition text-left cursor-pointer ${
                            selectedPaper === paper
                              ? 'bg-blue-600/20 border-cyan-400 text-white font-bold'
                              : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700'
                          }`}
                        >
                          {paper}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Finish Options */}
                {activeProduct.finishOptions && activeProduct.finishOptions.length > 0 && (
                  <div>
                    <label className="text-xs font-bold text-slate-300 block mb-1.5">Acabado Especial:</label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {activeProduct.finishOptions.map((finish) => (
                        <button
                          key={finish}
                          onClick={() => setSelectedFinish(finish)}
                          className={`p-2.5 text-xs font-medium rounded-xl border transition text-left cursor-pointer ${
                            selectedFinish === finish
                              ? 'bg-blue-600/20 border-cyan-400 text-white font-bold'
                              : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700'
                          }`}
                        >
                          {finish}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Quantity Input & Volume Tier Discounts */}
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-xs font-bold text-slate-300">
                      Cantidad de Unidades:
                    </label>
                    {currentDiscount > 0 && (
                      <span className="text-[11px] font-bold text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/30">
                        🎉 {(currentDiscount * 100).toFixed(0)}% Descuento por Volumen Aplicado
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-3">
                    <input
                      type="number"
                      min={activeProduct.minQuantity}
                      step={10}
                      value={quantity}
                      onChange={(e) => setQuantity(Math.max(activeProduct.minQuantity, Number(e.target.value)))}
                      className="w-32 bg-slate-950 border border-slate-700 rounded-xl px-4 py-2 text-white text-sm font-bold focus:outline-none focus:border-cyan-400"
                    />
                    <div className="flex gap-2 flex-wrap">
                      {activeProduct.quantityTier.map((tier) => (
                        <button
                          key={tier.qty}
                          onClick={() => setQuantity(tier.qty)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-bold cursor-pointer transition ${
                            quantity === tier.qty
                              ? 'bg-cyan-500 text-slate-950'
                              : 'bg-slate-950 text-slate-300 border border-slate-800 hover:border-slate-700'
                          }`}
                        >
                          {tier.qty} u.
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Artwork File Upload or Design Request */}
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                  <span className="text-xs font-bold text-white block">Diseño & Archivo para Imprenta:</span>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                    <label className={`p-3 rounded-xl border flex items-center gap-2 cursor-pointer transition ${!needDesignService ? 'bg-blue-950/40 border-cyan-400 text-white' : 'bg-slate-900 border-slate-800 text-slate-400'}`}>
                      <input
                        type="radio"
                        name="designChoice"
                        checked={!needDesignService}
                        onChange={() => setNeedDesignService(false)}
                        className="accent-cyan-400"
                      />
                      <Upload className="w-4 h-4 text-cyan-400" />
                      <span>Subir mi propio diseño (PDF / AI / PSD / JPG)</span>
                    </label>

                    <label className={`p-3 rounded-xl border flex items-center gap-2 cursor-pointer transition ${needDesignService ? 'bg-blue-950/40 border-cyan-400 text-white' : 'bg-slate-900 border-slate-800 text-slate-400'}`}>
                      <input
                        type="radio"
                        name="designChoice"
                        checked={needDesignService}
                        onChange={() => setNeedDesignService(true)}
                        className="accent-cyan-400"
                      />
                      <Sparkles className="w-4 h-4 text-cyan-400" />
                      <span>Diseño Personalizado Clic (+ L. 600.00)</span>
                    </label>
                  </div>

                  {!needDesignService && (
                    <div className="pt-2">
                      <input
                        type="text"
                        placeholder="Nombre de archivo (ej. tarjeta_clic_300dpi.pdf)"
                        value={uploadedFileName}
                        onChange={(e) => setUploadedFileName(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                      />
                    </div>
                  )}
                </div>

              </div>

              {/* Price Calculation & Add To Cart Button */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                  <div className="text-xs text-slate-400">Precio total estimado:</div>
                  <div className="text-2xl font-black text-cyan-400">
                    L. {total.toFixed(2)} <span className="text-xs text-slate-400 font-normal">HNL (L. {unitPrice}/u)</span>
                  </div>
                </div>

                <button
                  onClick={handleAddToCart}
                  className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white font-bold text-sm transition shadow-lg shadow-blue-600/25 flex items-center justify-center gap-2 cursor-pointer"
                >
                  <ShoppingBag className="w-5 h-5" />
                  <span>Agregar al Carrito</span>
                </button>
              </div>

              {/* Toast confirmation */}
              {addedToast && (
                <div className="p-3 bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold rounded-xl flex items-center gap-2 animate-bounce">
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span>¡Producto agregado al carrito de Clic exitosamente!</span>
                </div>
              )}

            </div>
          )}

        </div>

      </div>
    </section>
  );
};
