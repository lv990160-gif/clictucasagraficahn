import React from 'react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  variant?: 'dark' | 'light' | 'auto';
  showSubtitle?: boolean;
  className?: string;
}

export const Logo: React.FC<LogoProps> = ({
  size = 'md',
  variant = 'dark',
  showSubtitle = true,
  className = ''
}) => {
  // Height mapping
  const sizeClasses = {
    sm: 'h-8 sm:h-9',
    md: 'h-11 sm:h-12',
    lg: 'h-16 sm:h-20',
    xl: 'h-24 sm:h-28'
  };

  const textColor = variant === 'light' ? '#000000' : '#FFFFFF';
  const cyanColor = '#00A0E9'; // Official Clic Blue

  return (
    <div className={`inline-flex items-center select-none group ${className}`}>
      <svg
        viewBox="0 0 520 200"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={`${sizeClasses[size]} w-auto transition-transform duration-300 group-hover:scale-[1.02]`}
      >
        <g id="Official-CLIC-Logo">
          
          {/* FIRST 'C' WITH NOTCH FOR CYAN CURSOR */}
          <path
            d="M 125 15 
               C 92 2, 52 10, 28 32 
               C 8 52, 2 82, 12 108 
               C 16 118, 26 122, 38 116 
               C 48 110, 52 98, 48 88 
               C 42 75, 45 52, 60 42 
               C 76 30, 105 32, 122 45 
               L 155 18 
               C 145 10, 135 18, 125 15 Z"
            fill={textColor}
            style={{ display: 'none' }}
          />

          {/* MAIN WORDMARK "CLIC" (SVG Crisp Vectors) */}
          
          {/* FIRST C */}
          <path
            d="M 148 24 
               C 118 6, 68 8, 38 32 
               C 12 52, 2 85, 2 118 
               C 2 125, 8 128, 15 125 
               L 48 110 
               C 52 108, 54 102, 52 96 
               C 48 82, 50 58, 68 45 
               C 88 30, 122 34, 138 48 
               L 165 20 
               C 160 16, 154 26, 148 24 Z"
            fill={textColor}
            style={{ display: 'none' }}
          />

          {/* HIGH PRECISION VECTOR FOR "CLIC" + "TU CASA GRÁFICA" */}

          {/* First 'C' body */}
          <path
            d="M 148 20 C 122 5, 78 5, 48 22 C 22 38, 8 68, 8 98 C 8 108, 14 112, 22 108 L 52 94 C 58 91, 60 85, 58 78 C 55 68, 58 52, 70 42 C 85 30, 115 32, 130 44 L 162 18 C 158 14, 152 22, 148 20 Z"
            fill={textColor}
            style={{ display: 'none' }}
          />

          {/* RENDERED VECTOR GROUP */}
          <g>
            {/* Word CLIC */}
            <text
              x="0"
              y="122"
              fill={textColor}
              fontFamily="system-ui, -apple-system, 'Montserrat', 'Arial Black', sans-serif"
              fontWeight="900"
              fontSize="130"
              letterSpacing="-2"
            >
              CLIC
            </text>

            {/* Integrated Cyan Arrow Cursor (Top-right pointing, rounded corner polygon in lower-left of first C) */}
            <path
              d="M -12 118
                 C -22 105, -18 85, -2 80
                 L 48 65
                 C 62 60, 75 75, 68 90
                 L 42 135
                 C 35 148, 16 148, 8 135
                 Z"
              fill={cyanColor}
              style={{ display: 'none' }}
            />

            {/* CURSOR ARROW EXACT CUT (Fits directly inside the bottom left loop of C) */}
            <path
              d="M -15 110 
                 C -22 96 -10 78 5 82 
                 L 72 102 
                 C 86 106 88 126 74 134 
                 L 32 158 
                 C 18 166 -2 156 -8 140 
                 Z"
              fill={cyanColor}
              style={{ display: 'none' }}
            />

            {/* Precise Cyan Cursor Shape matching uploaded image */}
            <path
              d="M 5 85
                 C -10 82 -20 102 -10 118
                 L 12 145
                 C 20 156 38 152 42 138
                 L 68 82
                 C 72 70 60 58 48 62
                 L 22 72
                 C 14 75 8 78 5 85 Z"
              fill={cyanColor}
              style={{ display: 'none' }}
            />

            {/* OFFICIAL VECTOR ACCURACY CURSOR */}
            <g transform="translate(-16, 50) scale(1.12)">
              {/* Dark/White cut ring behind arrow */}
              <path
                d="M 10 38 C 4 20 22 4 38 16 L 86 54 C 96 62 90 80 76 80 L 46 80 C 38 80 32 86 32 94 L 32 116 C 32 130 14 136 6 122 Z"
                fill={variant === 'light' ? '#FFFFFF' : '#020617'}
                opacity="0.98"
              />
              {/* Bright Cyan Arrow Pointer */}
              <path
                d="M 14 42 
                   C 20 28 36 30 46 38 
                   L 80 64 
                   C 90 72 84 86 70 86 
                   L 44 86 
                   C 38 86 32 92 30 98 
                   L 20 116 
                   C 14 126 4 120 6 108 
                   L 10 68 
                   C 10 56 10 48 14 42 Z"
                fill={cyanColor}
              />
            </g>

            {/* "TU CASA GRÁFICA" SUBTITLE */}
            {showSubtitle && (
              <text
                x="2"
                y="180"
                fill={textColor}
                fontFamily="system-ui, -apple-system, 'Montserrat', 'Arial Black', sans-serif"
                fontWeight="900"
                fontSize="40"
                letterSpacing="6.2"
              >
                TU CASA GRÁFICA
              </text>
            )}
          </g>

        </g>
      </svg>
    </div>
  );
};
