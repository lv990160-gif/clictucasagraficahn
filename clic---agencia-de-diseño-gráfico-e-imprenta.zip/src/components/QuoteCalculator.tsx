import React, { useState, useEffect } from 'react';
import { Calculator, Sparkles, Send, CheckCircle2, Clock, DollarSign, FileText } from 'lucide-react';
import { QuoteRequestData } from '../types';

export const QuoteCalculator: React.FC = () => {
  const [serviceType, setServiceType] = useState<string>('tarjetas');
  const [quantity, setQuantity] = useState<number>(250);
  const [paperType, setPaperType] = useState<string>('coucle-350g');
  const [finishType, setFinishType] = useState<string>('soft-touch-uvi');
  const [urgency, setUrgency] = useState<'normal' | 'express' | 'super-express'>('normal');
  const [needDesign, setNeedDesign] = useState<boolean>(true);

  // Contact fields
  const [clientName, setClientName] = useState<string>('');
  const [clientEmail, setClientEmail] = useState<string>('');
  const [clientPhone, setClientPhone] = useState<string>('');
  const [details, setDetails] = useState<string>('');

  // Calculation result
  const [calculation, setCalculation] = useState<{
    unitPrice: number;
    totalEstimated: number;
    discountPercent: number;
    estimatedDays: number;
  }>({
    unitPrice: 5.50,
    totalEstimated: 1375.00,
    discountPercent: 12,
    estimatedDays: 3
  });

  const [submitted, setSubmitted] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);

  // Recalculate price via API
  useEffect(() => {
    const fetchEstimate = async () => {
      try {
        const res = await fetch('/api/quotes/calculate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            quantity,
            serviceType,
            paperType,
            finishType,
            urgency
          })
        });
        if (res.ok) {
          const data = await res.json();
          let finalTotal = data.totalEstimated;
          if (needDesign) finalTotal += 850; // Add design service estimate in Lempiras
          setCalculation({
            ...data,
            totalEstimated: parseFloat(finalTotal.toFixed(2))
          });
        }
      } catch (err) {
        console.error('Error fetching quote estimate:', err);
      }
    };

    fetchEstimate();
  }, [quantity, serviceType, paperType, finishType, urgency, needDesign]);

  const handleSubmitQuote = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
    }, 1000);
  };

  return (
    <section id="quote" className="py-20 bg-slate-900 text-white border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs font-bold uppercase tracking-wider">
            <Calculator className="w-3.5 h-3.5" />
            <span>Cotizador Interactivo Clic</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
            Calcula el Presupuesto de tu Proyecto al Instante
          </h2>
          <p className="text-slate-400 text-sm sm:text-base">
            Obtén un estimado transparente para servicios de imprenta o diseño gráfico según las especificaciones de tu proyecto.
          </p>
        </div>

        {/* Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Configurator Form */}
          <div className="lg:col-span-7 bg-slate-950 p-6 sm:p-8 rounded-2xl border border-slate-800 space-y-6 shadow-xl">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-cyan-400" />
              <span>1. Configura los Detalles de tu Pedido</span>
            </h3>

            {/* Service Type */}
            <div>
              <label className="text-xs font-bold text-slate-300 block mb-2">Tipo de Servicio Clic:</label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {[
                  { id: 'tarjetas', label: 'Tarjetas de Visita' },
                  { id: 'flyers', label: 'Flyers / Folletos' },
                  { id: 'roll-up', label: 'Roll-Up / Banners' },
                  { id: 'stickers', label: 'Stickers Troquelados' },
                  { id: 'bolsas', label: 'Bolsas Kraft' },
                  { id: 'branding', label: 'Diseño de Marca' }
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setServiceType(item.id)}
                    className={`p-3 text-xs font-bold rounded-xl border transition text-center cursor-pointer ${
                      serviceType === item.id
                        ? 'bg-blue-600 border-cyan-400 text-white shadow-md'
                        : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Quantity */}
            <div>
              <label className="text-xs font-bold text-slate-300 block mb-2">Cantidad Requerida:</label>
              <div className="flex items-center gap-4">
                <input
                  type="range"
                  min={50}
                  max={2500}
                  step={50}
                  value={quantity}
                  onChange={(e) => setQuantity(Number(e.target.value))}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
                <span className="text-base font-black text-cyan-400 min-w-[80px] text-right">
                  {quantity} u.
                </span>
              </div>
            </div>

            {/* Paper & Finish Options */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1.5">Soporte / Papel:</label>
                <select
                  value={paperType}
                  onChange={(e) => setPaperType(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-400"
                >
                  <option value="coucle-350g">Couclé 350g Ultra Blanco</option>
                  <option value="coucle-200g">Couclé Mate 200g</option>
                  <option value="kraft-300g">Papel Kraft Reciclado 300g</option>
                  <option value="texturado-400g">Papel Texturado Algodón 400g</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 block mb-1.5">Acabado Especial:</label>
                <select
                  value={finishType}
                  onChange={(e) => setFinishType(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-400"
                >
                  <option value="soft-touch-uvi">Soft Touch + UVI Sectorizado</option>
                  <option value="mate">Laminado Mate Básico</option>
                  <option value="stamping">Stamping Dorado / Plateado</option>
                  <option value="troquelado">Troquelado al Contorno</option>
                </select>
              </div>
            </div>

            {/* Urgency */}
            <div>
              <label className="text-xs font-bold text-slate-300 block mb-2">Plazo de Entrega:</label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'normal', label: 'Estándar (3-4 días)' },
                  { id: 'express', label: 'Express (48 horas)' },
                  { id: 'super-express', label: 'Urgente (24 horas)' }
                ].map((u) => (
                  <button
                    key={u.id}
                    type="button"
                    onClick={() => setUrgency(u.id as any)}
                    className={`p-2.5 text-[11px] font-bold rounded-xl border transition text-center cursor-pointer ${
                      urgency === u.id
                        ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    {u.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Need Graphic Design Service Checkbox */}
            <label className="flex items-center gap-3 p-3.5 rounded-xl bg-slate-900 border border-slate-800 cursor-pointer">
              <input
                type="checkbox"
                checked={needDesign}
                onChange={(e) => setNeedDesign(e.target.checked)}
                className="w-4 h-4 accent-cyan-400 rounded"
              />
              <div className="text-xs">
                <span className="font-bold text-white block">Incluir Servicio de Diseño Gráfico (+ L. 850.00)</span>
                <span className="text-slate-400">Nuestro equipo creará la propuesta gráfica desde cero con revisiones ilimitadas.</span>
              </div>
            </label>

          </div>

          {/* Estimate Display & Formal Request */}
          <div className="lg:col-span-5 bg-slate-950 p-6 sm:p-8 rounded-2xl border border-slate-800 space-y-6 shadow-xl flex flex-col justify-between">
            <div>
              <h3 className="text-lg font-bold text-white mb-4">Resumen del Estimado</h3>

              {/* Estimate Numbers */}
              <div className="p-5 rounded-xl bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span>Precio unitario aprox.:</span>
                  <strong className="text-slate-200">L. {calculation.unitPrice.toFixed(2)} / u</strong>
                </div>

                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span>Plazo de entrega estimado:</span>
                  <strong className="text-emerald-400">{calculation.estimatedDays} días hábiles</strong>
                </div>

                {calculation.discountPercent > 0 && (
                  <div className="flex items-center justify-between text-xs text-cyan-400">
                    <span>Descuento por volumen:</span>
                    <strong>-{calculation.discountPercent}%</strong>
                  </div>
                )}

                <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
                  <span className="text-sm font-bold text-slate-200">Total Estimado:</span>
                  <span className="text-3xl font-black bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
                    L. {calculation.totalEstimated.toFixed(2)} <span className="text-xs text-slate-400 font-normal">HNL</span>
                  </span>
                </div>
              </div>

              {/* Contact Form for Formal Quote Submission */}
              {!submitted ? (
                <form onSubmit={handleSubmitQuote} className="space-y-3 mt-6">
                  <h4 className="text-xs font-bold uppercase text-slate-400 tracking-wider">
                    Recibe la Cotización en tu Email:
                  </h4>

                  <input
                    type="text"
                    required
                    placeholder="Tu nombre o empresa"
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-400"
                  />

                  <input
                    type="email"
                    required
                    placeholder="Correo electrónico"
                    value={clientEmail}
                    onChange={(e) => setClientEmail(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-400"
                  />

                  <input
                    type="tel"
                    placeholder="Teléfono / WhatsApp"
                    value={clientPhone}
                    onChange={(e) => setClientPhone(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-400"
                  />

                  <textarea
                    rows={2}
                    placeholder="Detalles adicionales o notas del proyecto..."
                    value={details}
                    onChange={(e) => setDetails(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-400"
                  />

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full py-3.5 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white font-bold text-xs uppercase tracking-wider transition shadow-lg shadow-blue-600/20 flex items-center justify-center gap-2 cursor-pointer"
                  >
                    {loading ? (
                      <span>Procesando...</span>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        <span>Enviar Cotización a Clic Studio</span>
                      </>
                    )}
                  </button>
                </form>
              ) : (
                <div className="p-6 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-center space-y-3 mt-6">
                  <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
                  <h4 className="text-base font-bold text-white">¡Cotización Enviada!</h4>
                  <p className="text-xs text-slate-300">
                    Hemos recibido la información de tu proyecto ({clientName || 'Cliente'}). Un asesor creativo de Clic revisará tus especificaciones y te contactará en menos de 2 horas.
                  </p>
                  <button
                    onClick={() => setSubmitted(false)}
                    className="px-4 py-2 bg-slate-900 border border-slate-700 text-slate-300 rounded-lg text-xs font-bold hover:text-white"
                  >
                    Cotizar Otro Proyecto
                  </button>
                </div>
              )}
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
