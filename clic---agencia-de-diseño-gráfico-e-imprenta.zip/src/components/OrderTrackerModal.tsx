import React, { useState, useEffect } from 'react';
import { X, Search, CheckCircle2, Clock, Package, Truck, AlertCircle, Printer } from 'lucide-react';
import { OrderStatus } from '../types';

interface OrderTrackerModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialOrderId?: string;
}

export const OrderTrackerModal: React.FC<OrderTrackerModalProps> = ({
  isOpen,
  onClose,
  initialOrderId = 'CLIC-9821'
}) => {
  const [searchId, setSearchId] = useState<string>(initialOrderId);
  const [order, setOrder] = useState<OrderStatus | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(false);

  const fetchOrderDetails = async (idToSearch: string) => {
    if (!idToSearch.trim()) return;
    setLoading(true);
    setError(null);

    try {
      const res = await fetch(`/api/orders/track/${encodeURIComponent(idToSearch)}`);
      if (res.ok) {
        const data = await res.json();
        setOrder(data);
      } else {
        const errData = await res.json();
        setError(errData.error || 'No se encontró información del pedido.');
        setOrder(null);
      }
    } catch (err) {
      console.error('Error tracking order:', err);
      setError('Error al consultar el servidor. Intenta de nuevo.');
      setOrder(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen && initialOrderId) {
      setSearchId(initialOrderId);
      fetchOrderDetails(initialOrderId);
    }
  }, [isOpen, initialOrderId]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 text-white space-y-6 shadow-2xl my-8">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Search className="w-5 h-5 text-cyan-400" />
            <h3 className="text-lg font-bold text-white">Rastreador de Pedidos Clic Imprenta</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Bar */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            fetchOrderDetails(searchId);
          }}
          className="flex gap-2"
        >
          <input
            type="text"
            placeholder="Ingresa tu número de pedido (ej. CLIC-9821)"
            value={searchId}
            onChange={(e) => setSearchId(e.target.value)}
            className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-white focus:outline-none focus:border-cyan-400 uppercase font-mono"
          />
          <button
            type="submit"
            disabled={loading}
            className="px-5 py-2.5 bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-500 hover:to-cyan-400 text-white font-bold text-xs uppercase rounded-xl transition shadow-md cursor-pointer"
          >
            {loading ? 'Buscando...' : 'Buscar'}
          </button>
        </form>

        {/* Demo Code Helper Chip */}
        <div className="flex items-center gap-2 text-xs text-slate-400">
          <span>Prueba con el código demo:</span>
          <button
            type="button"
            onClick={() => {
              setSearchId('CLIC-9821');
              fetchOrderDetails('CLIC-9821');
            }}
            className="text-cyan-400 font-mono font-bold bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/30 hover:underline cursor-pointer"
          >
            CLIC-9821
          </button>
        </div>

        {/* Error message */}
        {error && (
          <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-400 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Order Details Result */}
        {order && (
          <div className="space-y-6 pt-2">
            
            {/* Meta info card */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs">
              <div>
                <span className="text-slate-400 block">Nº de Pedido:</span>
                <strong className="text-cyan-400 font-mono text-sm">{order.id}</strong>
              </div>
              <div>
                <span className="text-slate-400 block">Cliente:</span>
                <strong className="text-white text-xs">{order.customerName}</strong>
              </div>
              <div>
                <span className="text-slate-400 block">Fecha Registro:</span>
                <strong className="text-white text-xs">{order.date}</strong>
              </div>
              <div>
                <span className="text-slate-400 block">Entrega Estimada:</span>
                <strong className="text-emerald-400 text-xs">{order.estimatedDelivery}</strong>
              </div>
            </div>

            {/* Items Summary */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold uppercase text-slate-400">Artículos en Producción:</h4>
              <div className="space-y-1.5">
                {order.items.map((item, idx) => (
                  <div key={idx} className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs flex justify-between">
                    <div>
                      <strong className="text-white block">{item.name}</strong>
                      <span className="text-slate-400">{item.details}</span>
                    </div>
                    <span className="font-bold text-cyan-400">{item.quantity} u.</span>
                  </div>
                ))}
              </div>
            </div>

            {/* History Steps Timeline */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase text-slate-400">Progreso en Imprenta Clic:</h4>
              <div className="space-y-3 relative before:absolute before:inset-0 before:left-3.5 before:w-0.5 before:bg-slate-800">
                {order.history.map((step, idx) => (
                  <div key={idx} className="relative flex items-start gap-4 pl-8 text-xs">
                    <div className={`absolute left-0 top-0.5 w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs ${
                      step.completed
                        ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                        : 'bg-slate-950 text-slate-600 border border-slate-800'
                    }`}>
                      {step.completed ? <CheckCircle2 className="w-4 h-4" /> : idx + 1}
                    </div>

                    <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex-1 space-y-1">
                      <div className="flex items-center justify-between">
                        <strong className={`font-bold ${step.completed ? 'text-white' : 'text-slate-400'}`}>
                          {step.stage}
                        </strong>
                        <span className="text-[10px] text-slate-500">{step.date}</span>
                      </div>
                      <p className="text-slate-400 text-[11px]">{step.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

      </div>
    </div>
  );
};
