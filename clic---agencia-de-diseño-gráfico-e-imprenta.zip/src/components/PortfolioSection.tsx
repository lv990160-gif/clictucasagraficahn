import React, { useState } from 'react';
import { PORTFOLIO_ITEMS } from '../data/portfolioData';
import { PortfolioCategory, PortfolioItem } from '../types';
import { ExternalLink, X, Tag, Calendar, CheckCircle, Sparkles, Folder, ArrowRight } from 'lucide-react';

interface PortfolioSectionProps {
  onSelectProjectForQuote?: (item: PortfolioItem) => void;
}

export const PortfolioSection: React.FC<PortfolioSectionProps> = ({ onSelectProjectForQuote }) => {
  const [activeCategory, setActiveCategory] = useState<PortfolioCategory>('all');
  const [selectedItem, setSelectedItem] = useState<PortfolioItem | null>(null);

  const categories: { id: PortfolioCategory; label: string }[] = [
    { id: 'all', label: 'Todos los Trabajos' },
    { id: 'branding', label: 'Branding & Identidad' },
    { id: 'packaging', label: 'Packaging & Empaques' },
    { id: 'editorial', label: 'Diseño Editorial' },
    { id: 'gran-formato', label: 'Gran Formato' },
    { id: 'digital', label: 'Digital & Redes' },
  ];

  const filteredItems = activeCategory === 'all'
    ? PORTFOLIO_ITEMS
    : PORTFOLIO_ITEMS.filter((item) => item.category === activeCategory);

  return (
    <section id="portfolio" className="py-20 bg-slate-900 text-white border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs font-bold uppercase tracking-wider">
            <Folder className="w-3.5 h-3.5" />
            <span>Portafolio de Proyectos</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
            Diseños que generan impacto visual y comercial.
          </h2>
          <p className="text-slate-400 text-sm sm:text-base">
            Explora una selección de identidades corporativas, maquetación editorial, empaques personalizados e intervenciones gráficas en gran formato realizadas por nuestro equipo de creativos.
          </p>
        </div>

        {/* Filter Navigation */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-10">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer ${
                activeCategory === cat.id
                  ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow-lg shadow-blue-600/20'
                  : 'bg-slate-950/80 text-slate-300 hover:text-white border border-slate-800 hover:border-slate-700'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Portfolio Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              onClick={() => setSelectedItem(item)}
              className="group bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 hover:border-cyan-500/50 transition-all duration-300 hover:-translate-y-1.5 cursor-pointer flex flex-col justify-between shadow-xl"
            >
              <div>
                {/* Thumbnail Image Container */}
                <div className="relative aspect-video overflow-hidden bg-slate-900">
                  <img
                    src={item.image}
                    alt={item.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-3 left-3">
                    <span className="text-[10px] font-bold uppercase px-2.5 py-1 rounded-md bg-slate-950/80 backdrop-blur-md text-cyan-400 border border-slate-800">
                      {item.categoryLabel}
                    </span>
                  </div>
                </div>

                {/* Card Body */}
                <div className="p-6 space-y-3">
                  <div className="flex items-center justify-between text-xs text-slate-400 font-medium">
                    <span>Cliente: <strong className="text-slate-200">{item.client}</strong></span>
                    <span className="flex items-center gap-1"><Calendar className="w-3 h-3 text-cyan-400" /> {item.year}</span>
                  </div>

                  <h3 className="text-lg font-bold text-white group-hover:text-cyan-400 transition-colors line-clamp-1">
                    {item.title}
                  </h3>

                  <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                    {item.description}
                  </p>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-1.5 pt-2">
                    {item.tags.slice(0, 3).map((tag, i) => (
                      <span key={i} className="text-[10px] font-medium px-2 py-0.5 rounded bg-slate-900 text-slate-300 border border-slate-800">
                        #{tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Card Footer */}
              <div className="px-6 pb-6 pt-2 border-t border-slate-900 flex items-center justify-between text-xs font-bold text-cyan-400 group-hover:text-cyan-300">
                <span>Ver Detalles del Proyecto</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </div>

            </div>
          ))}
        </div>

      </div>

      {/* Project Detail Modal */}
      {selectedItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden my-8">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between p-6 border-b border-slate-800 bg-slate-950">
              <div className="space-y-1">
                <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider">
                  {selectedItem.categoryLabel}
                </span>
                <h3 className="text-xl sm:text-2xl font-black text-white">{selectedItem.title}</h3>
              </div>
              <button
                onClick={() => setSelectedItem(null)}
                className="p-2 rounded-xl bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800 transition"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 sm:p-8 space-y-6 max-h-[75vh] overflow-y-auto">
              
              {/* Main Image Showcase */}
              <div className="rounded-xl overflow-hidden border border-slate-800 aspect-video bg-slate-950">
                <img
                  src={selectedItem.image}
                  alt={selectedItem.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Project Specifications */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs">
                <div>
                  <span className="text-slate-400 block mb-0.5">Cliente:</span>
                  <strong className="text-white text-sm">{selectedItem.client}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block mb-0.5">Año de Ejecución:</span>
                  <strong className="text-white text-sm">{selectedItem.year}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block mb-0.5">Categoría Clic:</span>
                  <strong className="text-cyan-400 text-sm">{selectedItem.categoryLabel}</strong>
                </div>
              </div>

              {/* Challenge & Solution */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
                <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-2">
                  <h4 className="font-bold text-cyan-400 flex items-center gap-2">
                    <span>🎯 El Desafío del Cliente</span>
                  </h4>
                  <p className="text-slate-300 text-xs leading-relaxed">
                    {selectedItem.challenge || selectedItem.description}
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 space-y-2">
                  <h4 className="font-bold text-blue-400 flex items-center gap-2">
                    <span>💡 La Solución Clic Studio</span>
                  </h4>
                  <p className="text-slate-300 text-xs leading-relaxed">
                    {selectedItem.solution || selectedItem.description}
                  </p>
                </div>
              </div>

              {/* Deliverables List */}
              <div className="space-y-3">
                <h4 className="text-sm font-bold text-white">Entregables del Proyecto:</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  {selectedItem.deliverables.map((deliv, idx) => (
                    <div key={idx} className="flex items-center gap-2 p-2.5 rounded-lg bg-slate-950 border border-slate-800/80 text-slate-300">
                      <CheckCircle className="w-4 h-4 text-cyan-400 flex-shrink-0" />
                      <span>{deliv}</span>
                    </div>
                  ))}
                </div>
              </div>

            </div>

            {/* Modal Footer */}
            <div className="p-6 border-t border-slate-800 bg-slate-950 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="text-xs text-slate-400 text-center sm:text-left">
                ¿Te gusta este estilo visual para tu empresa o producto?
              </div>
              <button
                onClick={() => {
                  if (onSelectProjectForQuote) onSelectProjectForQuote(selectedItem);
                  setSelectedItem(null);
                }}
                className="w-full sm:w-auto px-6 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-bold text-sm transition flex items-center justify-center gap-2 shadow-lg shadow-blue-600/20 cursor-pointer"
              >
                <Sparkles className="w-4 h-4" />
                <span>Solicitar Proyecto Similar</span>
              </button>
            </div>

          </div>
        </div>
      )}

    </section>
  );
};
