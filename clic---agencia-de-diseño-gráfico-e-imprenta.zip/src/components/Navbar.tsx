import React, { useState } from 'react';
import { ShoppingBag, Sparkles, Search, Layers, FileText, Phone, ArrowUpRight, CheckCircle2, Menu, X } from 'lucide-react';
import { CartItem } from '../types';
import { Logo } from './Logo';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  cart: CartItem[];
  setIsCartOpen: (open: boolean) => void;
  setIsTrackerOpen: (open: boolean) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  cart,
  setIsCartOpen,
  setIsTrackerOpen
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const totalCartCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  const navLinks = [
    { id: 'hero', label: 'Inicio' },
    { id: 'portfolio', label: 'Portafolio' },
    { id: 'catalog', label: 'Catálogo & Tienda' },
    { id: 'quote', label: 'Cotizador Rápido' },
    { id: 'ai-assistant', label: 'Asistente Clic AI', badge: 'IA' },
    { id: 'contact', label: 'Contacto' },
  ];

  const handleNavClick = (id: string) => {
    setActiveTab(id);
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-slate-950/90 backdrop-blur-md border-b border-slate-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        
        {/* Brand Logo "Clic" */}
        <button 
          onClick={() => handleNavClick('hero')} 
          className="flex items-center text-left group cursor-pointer focus:outline-none"
        >
          <Logo size="md" />
        </button>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center gap-1 bg-slate-900/80 p-1.5 rounded-full border border-slate-800">
          {navLinks.map((link) => {
            const isActive = activeTab === link.id;
            return (
              <button
                key={link.id}
                onClick={() => handleNavClick(link.id)}
                className={`relative px-4 py-2 text-sm font-medium rounded-full transition-all flex items-center gap-1.5 cursor-pointer ${
                  isActive
                    ? 'bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow-md'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                {link.label}
                {link.badge && (
                  <span className="text-[10px] font-bold bg-cyan-400 text-slate-950 px-1.5 py-0.2 rounded-full uppercase tracking-wider">
                    {link.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Header Actions */}
        <div className="flex items-center gap-3">
          
          {/* Track Order Button */}
          <button
            onClick={() => setIsTrackerOpen(true)}
            className="hidden sm:flex items-center gap-2 text-xs font-semibold px-3.5 py-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:text-cyan-400 hover:border-slate-700 transition"
          >
            <Search className="w-3.5 h-3.5 text-cyan-400" />
            <span>Rastrear Pedido</span>
          </button>

          {/* Cart Drawer Trigger Button */}
          <button
            onClick={() => setIsCartOpen(true)}
            className="relative p-2.5 rounded-xl bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-200 hover:text-white transition cursor-pointer flex items-center gap-2"
            aria-label="Carrito de compra"
          >
            <ShoppingBag className="w-5 h-5 text-cyan-400" />
            {totalCartCount > 0 && (
              <span className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold text-xs px-2 py-0.5 rounded-full shadow-md">
                {totalCartCount}
              </span>
            )}
          </button>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-slate-900 border-b border-slate-800 px-4 py-4 space-y-2">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => handleNavClick(link.id)}
              className={`w-full text-left px-4 py-3 rounded-lg text-sm font-medium flex items-center justify-between ${
                activeTab === link.id
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-300 hover:bg-slate-800'
              }`}
            >
              <span>{link.label}</span>
              {link.badge && (
                <span className="text-[10px] font-bold bg-cyan-400 text-slate-950 px-2 py-0.5 rounded-full">
                  {link.badge}
                </span>
              )}
            </button>
          ))}
          <button
            onClick={() => {
              setIsTrackerOpen(true);
              setMobileMenuOpen(false);
            }}
            className="w-full text-left px-4 py-3 rounded-lg text-sm font-medium text-cyan-400 bg-slate-800/80 flex items-center gap-2 mt-2"
          >
            <Search className="w-4 h-4" />
            <span>Rastrear Estado de Pedido</span>
          </button>
        </div>
      )}
    </header>
  );
};
