import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { PortfolioSection } from './components/PortfolioSection';
import { CatalogSection } from './components/CatalogSection';
import { QuoteCalculator } from './components/QuoteCalculator';
import { AiDesignAssistant } from './components/AiDesignAssistant';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { CartDrawer } from './components/CartDrawer';
import { OrderTrackerModal } from './components/OrderTrackerModal';
import { CartItem, PortfolioItem } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('hero');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isTrackerOpen, setIsTrackerOpen] = useState<boolean>(false);
  const [trackerOrderId, setTrackerOrderId] = useState<string>('CLIC-9821');

  const handleAddToCart = (item: CartItem) => {
    setCart((prevCart) => {
      const existingIdx = prevCart.findIndex(
        (c) => c.product.id === item.product.id && c.selectedPaper === item.selectedPaper && c.selectedFinish === item.selectedFinish
      );
      if (existingIdx >= 0) {
        const updated = [...prevCart];
        updated[existingIdx].quantity += item.quantity;
        updated[existingIdx].totalPrice += item.totalPrice;
        return updated;
      }
      return [...prevCart, item];
    });
  };

  const handleUpdateQuantity = (cartId: string, qty: number) => {
    setCart((prevCart) =>
      prevCart.map((item) => {
        if (item.cartId === cartId) {
          const ratio = qty / item.quantity;
          return {
            ...item,
            quantity: qty,
            totalPrice: parseFloat((item.totalPrice * ratio).toFixed(2))
          };
        }
        return item;
      })
    );
  };

  const handleRemoveItem = (cartId: string) => {
    setCart((prevCart) => prevCart.filter((item) => item.cartId !== cartId));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  const handleOrderSuccess = (orderId: string) => {
    setTrackerOrderId(orderId);
    setIsTrackerOpen(true);
  };

  const handleSelectPortfolioForQuote = (item: PortfolioItem) => {
    setActiveTab('quote');
    const element = document.getElementById('quote');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 font-sans text-slate-100 antialiased selection:bg-cyan-500 selection:text-slate-950">
      
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        cart={cart}
        setIsCartOpen={setIsCartOpen}
        setIsTrackerOpen={setIsTrackerOpen}
      />

      {/* Main Content Sections */}
      <main>
        <HeroSection
          onExplorePortfolio={() => {
            setActiveTab('portfolio');
            document.getElementById('portfolio')?.scrollIntoView({ behavior: 'smooth' });
          }}
          onExploreCatalog={() => {
            setActiveTab('catalog');
            document.getElementById('catalog')?.scrollIntoView({ behavior: 'smooth' });
          }}
          onOpenQuote={() => {
            setActiveTab('quote');
            document.getElementById('quote')?.scrollIntoView({ behavior: 'smooth' });
          }}
        />

        <PortfolioSection onSelectProjectForQuote={handleSelectPortfolioForQuote} />

        <CatalogSection onAddToCart={handleAddToCart} />

        <QuoteCalculator />

        <AiDesignAssistant />

        <ContactSection />
      </main>

      {/* Footer */}
      <Footer />

      {/* Cart Slide-out Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
        onOrderSuccess={handleOrderSuccess}
      />

      {/* Order Status Tracker Modal */}
      <OrderTrackerModal
        isOpen={isTrackerOpen}
        onClose={() => setIsTrackerOpen(false)}
        initialOrderId={trackerOrderId}
      />

    </div>
  );
}
