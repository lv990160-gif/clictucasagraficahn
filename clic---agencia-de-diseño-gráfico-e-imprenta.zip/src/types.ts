export type PortfolioCategory = 'all' | 'branding' | 'editorial' | 'packaging' | 'gran-formato' | 'digital';

export interface PortfolioItem {
  id: string;
  title: string;
  client: string;
  category: PortfolioCategory;
  categoryLabel: string;
  image: string;
  gallery?: string[];
  description: string;
  challenge?: string;
  solution?: string;
  tags: string[];
  year: string;
  deliverables: string[];
}

export type ProductCategory = 'all' | 'tarjetas' | 'folletos' | 'gran-formato' | 'merchandising' | 'packaging';

export interface ProductOption {
  name: string;
  choices: {
    label: string;
    priceMultiplier?: number;
    priceAdder?: number;
  }[];
}

export interface PrintProduct {
  id: string;
  name: string;
  category: ProductCategory;
  categoryLabel: string;
  shortDesc: string;
  description: string;
  basePrice: number;
  image: string;
  minQuantity: number;
  quantityTier: { qty: number; discount: number }[];
  paperOptions?: string[];
  finishOptions?: string[];
  sizeOptions?: string[];
  productionDays: number;
  popular?: boolean;
}

export interface CartItem {
  cartId: string;
  product: PrintProduct;
  quantity: number;
  selectedSize?: string;
  selectedPaper?: string;
  selectedFinish?: string;
  needDesignService: boolean;
  uploadedFileName?: string;
  unitPrice: number;
  totalPrice: number;
  notes?: string;
}

export interface QuoteRequestData {
  serviceType: string;
  projectType: string;
  quantity: number;
  dimensions?: string;
  paperType?: string;
  finishType?: string;
  urgency: 'normal' | 'express' | 'super-express';
  needGraphicDesign: boolean;
  clientName: string;
  clientEmail: string;
  clientPhone: string;
  details: string;
  estimatedCost: number;
}

export interface OrderStatus {
  id: string;
  customerName: string;
  email: string;
  date: string;
  status: 'received' | 'prepress' | 'printing' | 'finishing' | 'shipping' | 'delivered';
  items: { name: string; quantity: number; details: string }[];
  totalAmount: number;
  estimatedDelivery: string;
  trackingNumber: string;
  history: {
    stage: string;
    date: string;
    completed: boolean;
    description: string;
  }[];
}

export interface AiChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  type?: 'general' | 'print-spec' | 'slogan' | 'palette';
  metadata?: any;
}
