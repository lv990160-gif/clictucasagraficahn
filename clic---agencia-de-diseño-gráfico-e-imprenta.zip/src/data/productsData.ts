import { PrintProduct } from '../types';

export const PRINT_PRODUCTS: PrintProduct[] = [
  {
    id: 'tarjetas-premium',
    name: 'Tarjetas de Presentación Premium (Soft Touch + Barniz UVI)',
    category: 'tarjetas',
    categoryLabel: 'Tarjetas Corporativas',
    shortDesc: 'Papel Papel Couclé 350g con laminado mate tacto terciopelo y brillo sectorizado UVI.',
    description: 'La tarjeta de visita que causa impacto instantáneo. Papel de máximo grosor 350g/m², plastificado mate aterciopelado (Soft Touch) y realce brillante en tu logotipo o detalles clave.',
    basePrice: 680.00,
    image: 'https://images.unsplash.com/photo-1589939705384-5185137a7f0f?auto=format&fit=crop&w=800&q=80',
    minQuantity: 100,
    quantityTier: [
      { qty: 100, discount: 0 },
      { qty: 250, discount: 0.15 },
      { qty: 500, discount: 0.25 },
      { qty: 1000, discount: 0.35 }
    ],
    paperOptions: ['Couclé 350g Ultra Blanco', 'Papel Reciclado Kraft 300g', 'Papel Texturizado Algodón 400g'],
    finishOptions: ['Laminado Soft Touch + UVI Sectorizado', 'Mate Elegante 2 Lados', 'Stamping Dorado en Caliente'],
    sizeOptions: ['Standard (85 x 55 mm)', 'Cuadrada (55 x 55 mm)', 'Bordes Redondeados (85 x 55 mm)'],
    productionDays: 3,
    popular: true
  },
  {
    id: 'flyers-promocionales',
    name: 'Flyers & Folletos Publicitarios A5 / A6',
    category: 'folletos',
    categoryLabel: 'Folletos e Impresos',
    shortDesc: 'Impresión full color offset alta resolución en papel Couclé 150g o 200g.',
    description: 'La herramienta definitiva para eventos, promociones y lanzamientos. Colores nítidos, saturación perfecta y acabado brillante o mate.',
    basePrice: 990.00,
    image: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=800&q=80',
    minQuantity: 250,
    quantityTier: [
      { qty: 250, discount: 0 },
      { qty: 500, discount: 0.20 },
      { qty: 1000, discount: 0.35 },
      { qty: 2500, discount: 0.50 }
    ],
    paperOptions: ['Couclé Brillante 150g', 'Couclé Mate 200g', 'Papel Ecológico 135g'],
    finishOptions: ['Corte Recto', 'Plegado Díptico', 'Plegado Tríptico C-Fold'],
    sizeOptions: ['Formato A6 (105 x 148 mm)', 'Formato A5 (148 x 210 mm)', 'Formato A4 (210 x 297 mm)'],
    productionDays: 2,
    popular: true
  },
  {
    id: 'roll-up-banner',
    name: 'Banner Roll-Up Publicitario Premium con Estuche',
    category: 'gran-formato',
    categoryLabel: 'Gran Formato',
    shortDesc: 'Estructura de aluminio auto-enrollable + lona poliéster mate anti-reflejos 85x200cm.',
    description: 'Portátil, resistente e impactante para exposiciones, ferias y puntos de venta. Incluye estructura metálica reforzada, lona HD de alta densidad y bolso de transporte acolchado.',
    basePrice: 1600.00,
    image: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=800&q=80',
    minQuantity: 1,
    quantityTier: [
      { qty: 1, discount: 0 },
      { qty: 3, discount: 0.10 },
      { qty: 5, discount: 0.18 },
      { qty: 10, discount: 0.25 }
    ],
    paperOptions: ['Lona Laminated PET 420g Anti-curvatura', 'Textil Poliéster Mate Eco'],
    finishOptions: ['Corte Limpio + Estuche Reforzado'],
    sizeOptions: ['Standard 85 x 200 cm', 'Grande 100 x 200 cm', 'XL 120 x 200 cm'],
    productionDays: 2,
    popular: true
  },
  {
    id: 'stickers-troquelados',
    name: 'Stickers & Pegatinas en Vinilo Troquelado',
    category: 'merchandising',
    categoryLabel: 'Merchandising & Adhesivos',
    shortDesc: 'Vinilo impermeable ultra-resistente con forma personalizada al contorno.',
    description: 'Adhesivos de vinilo de alta adhesión resistentes al agua, sol y roces. Ideales para empaques, laptop stickers, botellas y regalos de marca.',
    basePrice: 850.00,
    image: 'https://images.unsplash.com/photo-1572375992501-4b0892d50c69?auto=format&fit=crop&w=800&q=80',
    minQuantity: 100,
    quantityTier: [
      { qty: 100, discount: 0 },
      { qty: 250, discount: 0.15 },
      { qty: 500, discount: 0.30 },
      { qty: 1000, discount: 0.45 }
    ],
    paperOptions: ['Vinilo Blanco Impermeable', 'Vinilo Transparente Glass', 'Vinilo Holográfico'],
    finishOptions: ['Protección Laminado Mate', 'Protección Laminado Brillante'],
    sizeOptions: ['Chico (4x4 cm aproxi)', 'Mediano (6x6 cm aproxi)', 'Grande (8x8 cm aproxi)'],
    productionDays: 3,
    popular: true
  },
  {
    id: 'bolsas-kraft-custom',
    name: 'Bolsas Kraft Personalizadas con Tu Logo',
    category: 'packaging',
    categoryLabel: 'Packaging Corporativo',
    shortDesc: 'Bolsas ecológicas de papel Kraft 120g con impresión a 1 o 2 tintas.',
    description: 'Aporta elegancia ecológica a las compras de tus clientes. Papel reciclado de alta resistencia con asas retorcidas reforzadas e impresión ecológica a base de agua.',
    basePrice: 2350.00,
    image: 'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=800&q=80',
    minQuantity: 100,
    quantityTier: [
      { qty: 100, discount: 0 },
      { qty: 250, discount: 0.12 },
      { qty: 500, discount: 0.22 },
      { qty: 1000, discount: 0.35 }
    ],
    paperOptions: ['Kraft Natural Marrón 120g', 'Kraft Blanco Eco 130g'],
    finishOptions: ['Serigrafía 1 Color', 'Serigrafía 2 Colores / Full Color'],
    sizeOptions: ['Chica (18x24x8 cm)', 'Mediana (26x32x11 cm)', 'Grande (32x41x12 cm)'],
    productionDays: 5
  },
  {
    id: 'tazas-sublimadas',
    name: 'Tazas Cerámicas Personalizadas en Sublimación HD',
    category: 'merchandising',
    categoryLabel: 'Merchandising & Regalos',
    shortDesc: 'Taza de cerámica blanca 11oz apta para lavavajillas y microondas.',
    description: 'Impresión panorámica 360° en sublimación fotográfica de alta definición. Colores brillantes que no se desvanecen con el uso diario.',
    basePrice: 1100.00,
    image: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=800&q=80',
    minQuantity: 10,
    quantityTier: [
      { qty: 10, discount: 0 },
      { qty: 25, discount: 0.15 },
      { qty: 50, discount: 0.25 },
      { qty: 100, discount: 0.40 }
    ],
    paperOptions: ['Cerámica Blanca AAA 11oz', 'Cerámica Interior Color (Negro/Azul/Rojo)'],
    finishOptions: ['Sublimación Full Color Brillante'],
    sizeOptions: ['Capacidad Standard 325ml (11 oz)'],
    productionDays: 2
  },
  {
    id: 'carpetas-corporativas',
    name: 'Carpetas de Presentación Corporativa con Solapa',
    category: 'packaging',
    categoryLabel: 'Papelería Corporativa',
    shortDesc: 'Carpeta A4 en cartulina 350g con solapa interior para tarjetas de visita.',
    description: 'El toque profesional indiscutible para entregar presupuestos, contratos y propuestas comerciales a tus clientes VIP.',
    basePrice: 2700.00,
    image: 'https://images.unsplash.com/photo-1586281380349-632531db7ed4?auto=format&fit=crop&w=800&q=80',
    minQuantity: 50,
    quantityTier: [
      { qty: 50, discount: 0 },
      { qty: 100, discount: 0.15 },
      { qty: 250, discount: 0.28 },
      { qty: 500, discount: 0.40 }
    ],
    paperOptions: ['Cartulina Estucada 350g', 'Papel Reciclado Superior 300g'],
    finishOptions: ['Laminado Mate Exterior', 'Soft Touch + Barniz Sectorizado UVI en Logo'],
    sizeOptions: ['Para Documentos A4 (Cerrada 22 x 31 cm)'],
    productionDays: 4
  },
  {
    id: 'camisetas-impresas',
    name: 'Camisetas Algodón 100% con Impresión DTG / Serigrafía',
    category: 'merchandising',
    categoryLabel: 'Textil & Merchandising',
    shortDesc: 'Algodón peinado 180g con estampado directo digital suave al tacto.',
    description: 'Uniformes de trabajo, eventos o merchandising textil de tu marca. Impresión directa DTG sin relieves plastificados molestos o serigrafía industrial.',
    basePrice: 2100.00,
    image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=800&q=80',
    minQuantity: 10,
    quantityTier: [
      { qty: 10, discount: 0 },
      { qty: 25, discount: 0.15 },
      { qty: 50, discount: 0.28 },
      { qty: 100, discount: 0.42 }
    ],
    paperOptions: ['Algodón Ring-Spun 180g (Negro)', 'Algodón Ring-Spun 180g (Blanco)', 'Algodón Azul Marino'],
    finishOptions: ['DTG Impresión Digital Directa', 'Serigrafía 1-2 Colores'],
    sizeOptions: ['Mix de Tallas (S, M, L, XL, XXL)'],
    productionDays: 4
  }
];
