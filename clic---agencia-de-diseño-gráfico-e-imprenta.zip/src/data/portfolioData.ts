import { PortfolioItem } from '../types';
import clicCorporateIdentityImg from '../assets/images/clic_corporate_identity_1786157205301.jpg';
import clicEtiquetasImg from '../assets/images/clic_etiquetas_peanut_butter_1786157372272.jpg';

export const PORTFOLIO_ITEMS: PortfolioItem[] = [
  {
    id: 'branding-nova-tech',
    title: 'Identidad Corporativa & Material Promocional',
    client: 'Clic Studio & Clientes Corporativos',
    category: 'branding',
    categoryLabel: 'Branding e Identidad',
    image: clicCorporateIdentityImg,
    gallery: [
      clicCorporateIdentityImg,
      'https://images.unsplash.com/photo-1600132806370-bf17e65e942f?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1626785774573-4b799315345d?auto=format&fit=crop&w=1200&q=80'
    ],
    description: 'Aplicación de marca en material promocional para uso interno y externo, sobres, folders, credenciales y papelería corporativa.',
    challenge: 'Desarrollar una aplicación gráfica coherente en múltiples formatos de impresión y merchandising corporativo.',
    solution: 'Creamos un sistema de papelería física unificado con folders corporativos, sobres, credenciales y folletería con acabados de alta calidad.',
    tags: ['Identidad Corporativa', 'Folders', 'Sobres', 'Credenciales', 'Papelería'],
    year: '2026',
    deliverables: ['Folders Corporativos', 'Sobres Membretados', 'Credenciales con Lanyard', 'Papelería de Uso Interno/Externo', 'Manual de Marca']
  },
  {
    id: 'packaging-reserva-clic',
    title: 'Diseño & Impresión de Etiquetas y Empaques',
    client: 'Kurkees & Marcas Comerciales',
    category: 'packaging',
    categoryLabel: 'Packaging & Empaques',
    image: clicEtiquetasImg,
    gallery: [
      clicEtiquetasImg,
      'https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1563245372-f21724e3856d?auto=format&fit=crop&w=1200&q=80'
    ],
    description: 'Diseño de etiquetas adhesivas impermeables para frascos, empaques de alimentos y envases comerciales con impresión HD de alta durabilidad.',
    challenge: 'Crear una etiqueta comercial atractiva con información nutrimental clara, tabla de ingredientes y código de barras resistente a humedad y fricción.',
    solution: 'Desarrollamos una etiqueta en vinilo de alta adherencia con acabado brillante lavable y colores nítidos para destacar en anaquel.',
    tags: ['Etiquetas Adhesivas', 'Packaging', 'Diseño de Empaque', 'Vinilo Impermeable'],
    year: '2026',
    deliverables: ['Diseño de Etiqueta 360°', 'Tabla Nutricional e Ingredientes', 'Archivos de Preprensa Vectorial', 'Pruebas de Impresión HD']
  },
  {
    id: 'editorial-revista-arquitectura',
    title: 'Diseño Editorial Revista "Espacio & Ciudad"',
    client: 'Fundación Arquitectura Viva',
    category: 'editorial',
    categoryLabel: 'Diseño Editorial',
    image: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=1200&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=1200&q=80'
    ],
    description: 'Maquetación, dirección de arte gráfica e impresión de edición especial de 180 páginas en papel Couclé mate de 150g con lomo cosido a hilo.',
    challenge: 'Manejar grandes volúmenes de texto y fotografías de alta resolución manteniendo una rejilla limpia, elegante y fácil de leer.',
    solution: 'Implementamos un sistema reticular suizo de 12 columnas con amplios márgenes blancos e impresión offset de alta precisión tipográfica.',
    tags: ['Editorial', 'Maquetación InDesign', 'Impresión Offset', 'Encuadernación Cosida'],
    year: '2025',
    deliverables: ['Diseño de Portada e Interiores', 'Preprensa e Impresión Offset (3,000 ej)', 'Edición Digital PDF Interactivo']
  },
  {
    id: 'gran-formato-stand-expo',
    title: 'Señalética & Stand "Expo Innovación Clic"',
    client: 'Centro de Convenciones Metro',
    category: 'gran-formato',
    categoryLabel: 'Gran Formato & Eventos',
    image: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=1200&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=1200&q=80'
    ],
    description: 'Ambientación gráfica completa para recinto ferial: lonas backlit, vinilo microperforado para vidrieras, banners roll-up y tótem con letras en corpóreo iluminado.',
    challenge: 'Impactar visualmente a más de 15,000 visitantes con materiales de alta durabilidad y colores corporativos calibrados bajo iluminación de recinto.',
    solution: 'Producción de rotulación en impresión UV ecológica de 1440 dpi con acabado mate antireflejo e instalación profesional nocturna.',
    tags: ['Gran Formato', 'Vinilo Impreso', 'Letras Corpóreas', 'Backlit'],
    year: '2026',
    deliverables: ['12 Banners Roll-up Premium', 'Lona Frontlit de 15x4 metros', 'Vinil Microperforado 80m²', 'Instalación On-site']
  },
  {
    id: 'digital-campana-clic',
    title: 'Campaña Visual Digital & Redes "A Un Clic"',
    client: 'Clic Graphic Studio',
    category: 'digital',
    categoryLabel: 'Diseño Digital & Social',
    image: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1558655146-d09347e92766?auto=format&fit=crop&w=1200&q=80'
    ],
    description: 'Línea gráfica publicitaria multi-plataforma, animación de motion graphics para reels, kits de banners promocionales e ilustrativos.',
    challenge: 'Unificar la presencia digital de una marca activa en Instagram, LinkedIn y Meta Ads con un estilo moderno, vibrante y dinámico.',
    solution: 'Generamos un sistema de plantillas modulares dinámicas en Figma e Illustrator acompañadas de cápsulas de video animadas de 15 segundos.',
    tags: ['Motion Graphics', 'Social Media', 'UI Assets', 'Banner Ads'],
    year: '2026',
    deliverables: ['Kit de 40 Plantillas Redes', '5 Animaciones MP4 4K', 'Set de Banners Web Responsive']
  },
  {
    id: 'branding-lumina-cafe',
    title: 'Branding & Empaque Ecológico "Lumina Cafe"',
    client: 'Lumina Specialty Coffee',
    category: 'branding',
    categoryLabel: 'Branding e Identidad',
    image: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=1200&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=1200&q=80'
    ],
    description: 'Identidad gráfica para barra de café artesanal, bolsas kraft compostables con sellos en serigrafía, vasos térmicos personalizados y menús desplegables.',
    challenge: 'Proyectar sostenibilidad ecológica sin descuidar una estética sofisticada y memorable.',
    solution: 'Elegimos una paleta de tonos tierra y verde oliva, con tipografía artesanal y empaques en papel kraft 100% reciclado.',
    tags: ['Cafetería', 'Empaque Kraft', 'Serigrafía', 'Menú Impreso'],
    year: '2025',
    deliverables: ['Diseño de Logo & Variantes', 'Bolsas de Café con Válvula', 'Vasos Térmicos Impresos', 'Menú de Malla Rígida']
  }
];
